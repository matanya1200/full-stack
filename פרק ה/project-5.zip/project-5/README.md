C:\Users\matan\OneDrive\Desktop\לימודים\שנה ד\full stack\פרק ה\project-5
json-server --watch db.json --port 3001
npm run dev
http://localhost:3001
http://localhost:5173/
